﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using NetCharm.Image.Addins;

namespace $rootnamespace$
{
    public partial class $safeitemname$Form : Form
    {
        internal AddinHost host;
        private IAddin addin;

        public $safeitemname$()
        {
            InitializeComponent();
        }

        public $safeitemname$Form( IAddin filter )
        {
            this.addin = filter;
            InitializeComponent();

            toolTip.ToolTipTitle = addin.DisplayName;
            AddinUtils.Translate( addin, this, toolTip );
        }
    }
}
